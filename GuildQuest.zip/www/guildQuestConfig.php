<?php

$host = "127.0.0.1";			// localhost
$user = "";				// username for MySQL
$password = "";			// password for MySQL
$dbname = "GuildQuest";			// our database name
$port = 3306				// default port for MySQL

?>
